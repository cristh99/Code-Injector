# JANO v1.0.0-experimental — manual operativo y límites

> **Usar cuando:** una cola, Action o árbol conserva trabajos `READY`, `BLOCKED`, `DRAFT`, `WORKING` o `VERIFYING` y debe decidirse, antes de abrir otra hoja, si cada carril sigue siendo necesario.

## Estado
- Estado documental: `TESTED_DRAFT_LIMITED_USE`.
- Producción: `no aplicado`; sólo auditoría read-only y canario.
- Owner y autoridad: `cristh99/Code-Injector`, rama `jano-reconsideration-v1`; el commit y los hashes exactos deben resolverse por readback antes de usar.
- Corte del canario: `2026-08-14T01:46:00Z`.
- QA distinta: pendiente; ningún veredicto de JANO autoriza una mutación.

## Qué resuelve
JANO operacionaliza `KB_CONTEXT_AND_RECONSIDERATION_GATE_V1`. Convierte un snapshot congelado del grafo de trabajo en un receipt determinista con exactamente uno de seis veredictos por hoja activa: `MATAR`, `CAMBIAR`, `MOVER`, `FUSIONAR`, `CREAR` o `SIN_CAMBIO`. Detecta sucesores explícitos, cadenas rotas, trabajos stale sin dueño, dependientes que deben retargetearse, duplicados con canonical explícito y ancestros que requieren reconsideración.

## No es
- No es dispatcher, scheduler, coordinador ni mutador de Neon.
- No sustituye FORJA, LLAVE, ARCA, CRONOS, Tree Guardian ni el canon de Notion.
- No decide verdad material, prioridad política ni suficiencia de evidencia del mundo.
- No garantiza que un snapshot sea completo; sólo prueba la decisión sobre los bytes suministrados.

## Prerrequisitos
1. Acceso read-only a `work_items_v2`, `work_assignments_v2` y `work_dependencies_v2`, o un snapshot equivalente.
2. Corte UTC explícito y snapshot conservado por bytes/hash.
3. Identificadores de sucesión explícitos; JANO no infiere sucesión por parecido de títulos.
4. `semantic_key` y exactamente un `canonical_for_merge=true` para emitir `FUSIONAR`.
5. `required_child_missing=true` para emitir `CREAR`.
6. Presupuesto externo `US$0` y entorno sin rutas de mutación.

## Entradas
| Campo | Tipo/formato | Regla |
|---|---|---|
| `schema_version` | string | exacto `evidencia-publica.jano.snapshot/v1` |
| `snapshot_id` | string no vacío | identifica el corte, no reemplaza el SHA |
| `captured_at` | ISO-8601 con zona | no puede ser posterior a `as_of` |
| `works[]` | objetos | IDs UUID únicos y estados enumerados |
| `has_live_assignment` | boolean | calculado contra lease vivo |
| `pending_dependencies` | entero no negativo | dependencias del trabajo aún pendientes |
| `pending_dependents` | entero no negativo | trabajos que aún dependen de él |
| `metadata` | objeto | sólo campos explícitos de sucesión, creación o movimiento influyen |

## Salidas y status codes
| Status | Significado | Acción |
|---|---|---|
| Exit `0` | receipt válido, hash-bound y sin mutaciones | enviar a QA distinta; no aplicar automáticamente |
| Exit `2` / `JANO_FAIL_CLOSED` | snapshot inválido, ambiguo, cíclico o inconsistente | detenerse y corregir evidencia |
| Exit `3` / `JANO_IO_ERROR` | lectura o escritura local falló | conservar inputs; no promover |

Los veredictos significan:
- `MATAR`: existe una cadena sucesora explícita y viable; no hay dependientes pendientes.
- `CAMBIAR`: el carril requiere corrección o retarget antes de cerrarse.
- `MOVER`: trabajo stale, sin dueño y sin dependencia que justifique permanecer donde está.
- `FUSIONAR`: duplicado semántico explícito con canonical único.
- `CREAR`: falta un hijo requerido declarado expresamente; es el último recurso.
- `SIN_CAMBIO`: lease vivo, dependencia pendiente o evidencia insuficiente para alterar la estrategia.

## Ruta segura
1. Congelar el corte y ejecutar `sql/export_active_work_snapshot.sql` en modo read-only.
2. Guardar los bytes exactos del snapshot y su SHA-256.
3. Ejecutar `python -m jano.cli audit --snapshot SNAPSHOT --as-of UTC --output RECEIPT`.
4. Verificar `snapshot_sha256`, `policy_sha256` y `receipt_sha256`.
5. Revisar razones, cadenas sucesoras y `ancestor_recheck_ids`.
6. Pedir QA distinta contra snapshot, política y receipt exactos.
7. Sólo otro procedimiento autorizado puede materializar disposiciones; JANO permanece read-only.

## Uso correcto
- Detectar que dos carriles V15 bloqueados deben `MATAR` porque el sucesor chunked exacto está `COMPLETED`.
- Responder `CAMBIAR`, no `MATAR`, cuando el sucesor directo fue cancelado y no existe ID del reemplazo siguiente.
- Responder `SIN_CAMBIO` a una hoja `VERIFYING` con lease vivo.

## Uso prohibido
- No usar parecido textual, números de versión o antigüedad por sí solos para matar trabajo.
- No cancelar, superseder, reasignar, publicar mensajes ni editar Notion desde JANO.
- No convertir `MATAR` en ejecución automática antes de QA distinta y autorización.
- No omitir trabajos terminales usados como referencias de una cadena sucesora.
- No forzar `FUSIONAR` sin canonical explícito ni `CREAR` sin evidencia literal.

## Fallos y respuesta
| Fallo | Detección | Respuesta fail-closed |
|---|---|---|
| ID duplicado | `DUPLICATE_WORK_ID` | rechazar snapshot completo |
| ciclo de sucesión | `SUCCESSOR_CYCLE` | rechazar; no escoger ganador |
| múltiples sucesores | `AMBIGUOUS_SUCCESSOR` | rechazar; adjudicar autoridad |
| canonical de merge ausente/duplicado | `MERGE_CANONICAL_REQUIRED` | no fusionar |
| sucesor fuera del snapshot | veredicto `CAMBIAR` | ampliar snapshot y repetir |
| tiempo futuro o sin zona | error de timestamp | congelar corte correcto |
| estado no enumerado | `WORK_STATUS_NOT_ALLOWED` | reconciliar contrato de estado |

## Evidencia mínima
- Snapshot exacto y SHA-256.
- Política exacta y `policy_sha256`.
- Receipt exacto y `receipt_sha256`.
- Versión del código, commit y release manifest.
- Corte UTC, stale window y conteos por veredicto.
- Productor distinto del verificador.
- Proof boundary: recomendaciones sobre el snapshot, cero mutaciones.

## Autoridad material
- Código: `cristh99/Code-Injector`, rama `jano-reconsideration-v1`, directorio `jano/`.
- Release local reproducible: `jano-v1.0.0-experimental.tar.gz` y manifest compañero.
- La autoridad final es el commit leído de vuelta más los hashes del manifest; un nombre de rama no basta.

## QA y canario
- Uso: snapshot vivo de 15 filas — 11 hojas activas y 4 referencias terminales.
- Resultado esperado: `MATAR=4`, `CAMBIAR=4`, `MOVER=1`, `FUSIONAR=0`, `CREAR=0`, `SIN_CAMBIO=2`.
- Rechazos: ciclo, ID duplicado, canonical de merge ambiguo, tiempo futuro y schema incorrecto.
- Canario local: 18 pruebas del motor/CLI más contratos y release reproducible.
- Verificador distinto: obligatorio antes de promover estado documental.

## Producción, rollback y sucesión
- Estado productivo: cero objetos y cero mutaciones en Neon.
- Autorización requerida: QA distinta hash-bound y decisión separada de integración.
- Rollback: retirar la rama/release; ningún estado vivo necesita restauración.
- Supersedes: `null`.
- Superseded by: `null`.

## Palabras de activación
`JANO`, `reconsiderar`, `trabajo obsoleto`, `subacción innecesaria`, `sucesor`, `stale`, `duplicación`, `MATAR`, `CAMBIAR`, `MOVER`, `FUSIONAR`, `CREAR`, `SIN_CAMBIO`.

## Proof boundary
JANO demuestra que una política determinista produjo un receipt sobre un snapshot concreto. No demuestra que la evidencia externa sea verdadera, que el snapshot incluya todo el universo ni que ejecutar la recomendación sea autorizado o seguro.
