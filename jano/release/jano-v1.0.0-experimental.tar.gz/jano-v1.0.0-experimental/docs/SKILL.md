---
name: using-jano-reconsideration
summary: Use JANO without mutating work state.
description: Use when an Action, queue, work graph, or set of sibling tasks may contain obsolete, superseded, orphaned, duplicated, stale, or still-necessary work.
---

# Using JANO

## Load rule
Cargue esta skill ante cualquier mención de `JANO`, reconsideración macro, hojas obsoletas, sucesores, duplicación de trabajo o los veredictos `MATAR`, `CAMBIAR`, `MOVER`, `FUSIONAR`, `CREAR`, `SIN_CAMBIO`.

## Preconditions
- Lea `docs/MANUAL.md` completo.
- Use un snapshot congelado y hashable; incluya referencias terminales de las cadenas sucesoras.
- Confirme versión, commit, release manifest y estado documental vivos.
- JANO sólo opera en `READ_ONLY_RECONSIDERATION`.

## Command
```bash
PYTHONPATH=src python -m jano.cli audit \
  --snapshot snapshot.json \
  --as-of 2026-08-14T01:46:00Z \
  --stale-hours 6 \
  --output receipt.json
```

## Interpretation
- `MATAR`: candidato a cierre por sucesor explícito viable; todavía requiere QA y autorización.
- `CAMBIAR`: corregir cadena, dependientes, liveness o contrato.
- `MOVER`: reubicar o reasignar trabajo stale sin dueño.
- `FUSIONAR`: usar únicamente el canonical explícito.
- `CREAR`: sólo por `required_child_missing=true`.
- `SIN_CAMBIO`: conservar el carril.

## No ejecutar
No ejecute cancelaciones, supersessiones, reasignaciones, mensajes, cambios de dependencias ni ediciones de Notion a partir del receipt. No use títulos parecidos como sucesión. No promueva si falta snapshot SHA, policy SHA, receipt SHA o QA distinta.

## Fail-closed
Deténgase si el CLI sale distinto de `0`, si hay ciclo, múltiples sucesores, canonical ambiguo, ID duplicado, timestamp inválido, referencia faltante material o divergencia de hash.
