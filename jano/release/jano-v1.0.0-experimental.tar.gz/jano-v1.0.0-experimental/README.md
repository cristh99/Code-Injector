# JANO

JANO convierte un snapshot read-only del grafo de trabajo de EVIDENCIA_PUBLICA en un receipt determinista de reconsideración: `MATAR`, `CAMBIAR`, `MOVER`, `FUSIONAR`, `CREAR` o `SIN_CAMBIO`.

## Quick start

```bash
PYTHONPATH=src python -m jano.cli audit \
  --snapshot tests/fixtures/live_canary.json \
  --as-of 2026-08-14T01:46:00Z \
  --stale-hours 6 \
  --output /tmp/jano-receipt.json \
  --pretty
```

## Verify

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
python scripts/build_release.py --root . --out-dir release
```

## Safety

JANO never mutates work state. A receipt is a recommendation bound to a snapshot and policy, not authorization to execute it. Basic Memory is prohibited; external spend is US$0.
