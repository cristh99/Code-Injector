#!/usr/bin/env node
import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = dirname(fileURLToPath(import.meta.url));
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex');
const inventory = (await readFile(join(root, 'SHA256SUMS'), 'utf8')).trim().split('\n').filter(Boolean);
const failures = [];
for (const line of inventory) {
  const match = line.match(/^([0-9a-f]{64})  (.+)$/);
  if (!match) { failures.push(`BAD_INVENTORY_LINE:${line}`); continue; }
  const [, expected, relative] = match;
  const observed = sha256(await readFile(resolve(root, relative)));
  if (observed !== expected) failures.push(`HASH_MISMATCH:${relative}:${expected}:${observed}`);
}
const manifest = JSON.parse(await readFile(join(root, 'RELEASE-MANIFEST.json'), 'utf8'));
const pkgPath = join(root, manifest.package.path);
const pkgBytes = await readFile(pkgPath);
if (pkgBytes.length !== manifest.package.size_bytes) failures.push('PACKAGE_SIZE_MISMATCH');
if (sha256(pkgBytes) !== manifest.package.sha256) failures.push('PACKAGE_HASH_MISMATCH');
const pkg = JSON.parse(execFileSync('tar', ['-xOf', pkgPath, 'package/package.json'], { encoding: 'utf8' }));
if (pkg.name !== '@evidencia-publica/llave' || pkg.version !== '1.0.0') failures.push('PACKAGE_IDENTITY_MISMATCH');
const vector = JSON.parse(await readFile(join(root, 'verification/clean-install-contract-hash.json'), 'utf8'));
if (vector.contract_sha256 !== '72d065cb9bab85897dbc6f19396da1039b30c639cdda4b70277293f86d28c63c') failures.push('CONTRACT_VECTOR_MISMATCH');
const denial = JSON.parse(await readFile(join(root, 'verification/clean-install-denial.json'), 'utf8'));
if (denial.authorized !== false || !denial.reasons?.some((r) => r.code === 'RESOURCE_NOT_COVERED')) failures.push('FAIL_CLOSED_DENIAL_MISMATCH');
const schema = JSON.parse(await readFile(join(root, 'source/llave/LLAVE-V1-SCHEMA-MANIFEST.json'), 'utf8'));
if (!schema.contract_identity.node_postgres_parity) failures.push('SCHEMA_PARITY_NOT_BOUND');
const canary = JSON.parse(await readFile(join(root, 'source/llave/LLAVE-V1-CANARY-RECEIPT.json'), 'utf8'));
if (!canary.checks?.all_pass || !canary.production_neon_branch?.unchanged) failures.push('CANARY_BOUNDARY_MISMATCH');
if (failures.length) { process.stderr.write(`${JSON.stringify({ valid: false, failures })}\n`); process.exit(1); }
process.stdout.write(`${JSON.stringify({valid:true,artifact:manifest.artifact,version:manifest.version,source_commit:manifest.source_commit,package_sha256:manifest.package.sha256,inventory_entries:inventory.length,contract_sha256:vector.contract_sha256,production_applied:manifest.boundaries.production_migration_applied,external_spend_usd:manifest.boundaries.external_spend_usd})}\n`);
